package com.pzombade.shoppingspringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoppingSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
