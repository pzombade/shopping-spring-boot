package com.pzombade.shoppingspringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShoppingSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShoppingSpringBootApplication.class, args);
	}

}
